from odoo import models, fields

class Doctor(models.Model):
    _name = 'hospital.doctor'
    _description = 'Doctor'

    name = fields.Char(string='Name', required=True)
    specialization = fields.Char(string='Specialization')
    license_number = fields.Char(string='License Number', required=True)
    phone = fields.Char(string='Phone Number')
    email = fields.Char(string='Email')
    is_active = fields.Boolean(string='Active', default=True)

    appointment_ids = fields.One2many('hospital.appointment', 'doctor_id', string="Appointments")
