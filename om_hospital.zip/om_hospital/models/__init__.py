from . import patient
from . import doctor
from . import appointment
from . import appointment_line
from . import patient_tag
from . import menu_access



