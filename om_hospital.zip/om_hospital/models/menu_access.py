from odoo import models, api

class IrUiMenu(models.Model):
    _inherit = 'ir.ui.menu'

    @api.model
    def get_user_roots(self):
        """
        Override to hide the Settings menu for users with Administration settings but no access.
        """
        roots = super(IrUiMenu, self).get_user_roots()
        user = self.env.user

        # Reference the Settings menu by its technical name
        settings_menu = self.env.ref('base.menu_administration', raise_if_not_found=False)

        # If the user is not a system admin, hide the Settings menu
        if settings_menu and not user.has_group('base.group_system'):
            roots = [menu for menu in roots if menu.id != settings_menu.id]

        return roots
