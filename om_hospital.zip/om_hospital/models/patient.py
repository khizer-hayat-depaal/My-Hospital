from odoo import api, fields, models


class HospitalPatient(models.Model):
    _name = 'hospital.patient'
    _inherit = ['mail.thread']
    _description = 'Patient Master'

    name = fields.Char(string="Name", required=True, tracking=True)
    age = fields.Integer(string="age", tracking=True)
    date_of_birth = fields.Date(string="Date of Birth")
    gender = fields.Selection([('male', 'Male'), ('female', 'Female')], string="Gender")
    contact_number = fields.Integer(string="contact_number")
    address = fields.Char(string="address")

    tag_ids = fields.Many2many(
        'patient.tag', 'patient_tag_rel', 'patient_id', string='Tags'
    )
    appointment_ids = fields.One2many('hospital.appointment', 'patient_id', string="Appointments")