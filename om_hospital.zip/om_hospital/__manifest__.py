{
    "name": "Hospital Management System",
    "author": "Khizer Hayat Depaal",
    "license": "LGPL-3",
    "version": "17.0.1.1",
    "depends": [
        'base', 'mail', 'product', 'contacts', 'account',

    ],
    "data": [
        "security/security.xml",
        "security/ir.model.access.csv",

        "data/sequence.xml",

        "views/patient_readonly_views.xml",
        "views/appointment_line_views.xml",
        "views/appointment_views.xml",
        "views/patient_tag_views.xml",
        "views/patient_views.xml",
        "views/doctor_views.xml",
        "views/menu.xml",
        # "views/views.xml",

        "report/patient_card_template.xml",
        "report/patient_card_report.xml",
        "report/doctor_card_template.xml",
        "report/doctor_card_report.xml",

    ],
    'images': [
        'static/description/patient.png',
    ],

    'category': 'Hospital',
    'installable': True,
    'application': True,

}
