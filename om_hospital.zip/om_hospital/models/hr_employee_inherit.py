from odoo import models, fields

class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    hospital_id = fields.Many2one('hospital.hospital', string='Hospital', help="Hospital where the employee works")
    department = fields.Char(string='Department', help="Department in the hospital")
    designation = fields.Char(string='Designation', help="Employee's designation in the hospital")
