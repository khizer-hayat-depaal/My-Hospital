# from email.policy import default

from odoo import api, fields, models


class HospitalAppointmentLine(models.Model):
    _name = 'hospital.appointment.line'
    _description = 'Hospital Appointment Line'

    appointment_id = fields.Many2one('hospital.appointment', string="Appointment", required=True, ondelete='cascade')
    product_id = fields.Many2one('product.product', string="Product", required=True)
    qty = fields.Float(string="Quantity")
